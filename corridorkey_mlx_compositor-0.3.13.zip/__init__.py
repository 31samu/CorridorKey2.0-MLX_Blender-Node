# SPDX-License-Identifier: GPL-3.0-or-later

import json
import os
from pathlib import Path
import re
import signal
import subprocess
import uuid

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, CompositorNodeCustomGroup, Operator

from . import setup_ui

ADDON_ID = __package__
NODE_ID = "CompositorNodeCorridorKeyMLX"
NODE_LABEL = "CorridorKey2.0 (MLX)"
JOBS = {}
ANALYSIS_BUSY_MESSAGE = "Wait for analysis to finish."
OUTPUT_SEQUENCES = {
    "cutout": "Keyed Frames",
    "fg": "Despilled Foreground",
    "raw_fg": "Raw Foreground",
}
MORE_OUTPUTS = ("Matte", "Despilled Foreground", "Raw Foreground", "Edges")
GARBAGE_MASK_DESCRIPTION = "Live mask for the keyed result. White keeps foreground and black removes it."
UNBAKED_HINT_NODE = "Unbaked Matte Hint"
PROFILE_SIZES = {"720": (768, 1280, 720), "1024": (1024, 1536, 1024)}
PROGRESS_LINE = re.compile(rb"^(Bake|Features|Export) (\d+)/(\d+)$", re.MULTILINE)
ANALYSIS_STAGES = {b"Bake": (1, "Baking input"), b"Features": (2, "Analyzing source"), b"Export": (3, "Keying frames")}


def absolute_path(value):
    return Path(bpy.path.abspath(value)).expanduser().resolve()


def job_command(executable, model_root, source, destination, screen, profile="720"):
    height, width, _ = PROFILE_SIZES[profile]
    return [
        str(executable), "--model-root", str(model_root),
        "--input", str(source), "--output-dir", str(destination),
        "--height", str(height), "--width", str(width),
        "--precision", "fp16", "--screen", screen,
        "--hann-chunk", "1", "--hann-stride", "1",
        "--image-sequence", "--outputs", *OUTPUT_SEQUENCES,
    ]


def find_frames(destination):
    frames = sorted(destination.rglob("*.png"))
    if not frames:
        raise ValueError("The backend did not write a cutout PNG sequence.")
    parts = [re.fullmatch(r"(.*?)([0-9]+)\.png", frame.name) for frame in frames]
    first = parts[0]
    if not first or any(
        part is None
        or frame.parent != frames[0].parent
        or part[1] != first[1]
        or len(part[2]) != len(first[2])
        or int(part[2]) != int(first[2]) + index
        for index, (frame, part) in enumerate(zip(frames, parts))
    ):
        raise ValueError("The backend output is not one contiguous PNG sequence.")
    return frames


def publish_sequence(node, destination, start_frame):
    sequences = {name: find_frames(destination / folder) for folder, name in OUTPUT_SEQUENCES.items()}
    frame_count = len(sequences["Keyed Frames"])
    if any(len(frames) != frame_count for frames in sequences.values()):
        raise ValueError("The backend output sequences have different frame counts.")
    images = {}
    try:
        for name, frames in sequences.items():
            image = bpy.data.images.load(str(frames[0]), check_existing=False)
            images[name] = image
            image.source = "SEQUENCE"
            image.filepath = str(frames[0])
            image.alpha_mode = "STRAIGHT" if name == "Keyed Frames" else "NONE"
    except Exception:
        for image in images.values():
            bpy.data.images.remove(image)
        raise

    tree = node.node_tree
    for name, image in images.items():
        source = tree.nodes[name]
        previous = source.image
        source.image = image
        source.frame_duration = frame_count
        source.frame_start = start_frame
        source.frame_offset = int(re.search(r"[0-9]+(?=\.png$)", image.filepath)[0]) - 1
        source.use_auto_refresh = True
        if previous and previous.users == 0:
            bpy.data.images.remove(previous)
    update_image_output(tree)
    return frame_count


def set_start_frame(node, _context):
    if node.node_tree:
        for name in OUTPUT_SEQUENCES.values():
            if source := node.node_tree.nodes.get(name):
                source.frame_start = node.start_frame


class CorridorKeyPreferences(AddonPreferences):
    bl_idname = ADDON_ID

    executable: StringProperty(name="MLX executable", subtype="FILE_PATH")
    model_root: StringProperty(name="FP16 model folder", subtype="DIR_PATH")
    cache_root: StringProperty(name="Cache folder", subtype="DIR_PATH")
    show_advanced: BoolProperty(name="Advanced", default=False)

    def draw(self, context):
        layout = self.layout
        setup_ui.draw_setup(layout, self)
        row = layout.row(align=True)
        row.alignment = "LEFT"
        row.prop(self, "show_advanced", emboss=False, icon="TRIA_DOWN" if self.show_advanced else "TRIA_RIGHT")
        if self.show_advanced:
            layout.prop(self, "executable")
            layout.prop(self, "model_root")
            layout.prop(self, "cache_root")


class CorridorKeyNode(CompositorNodeCustomGroup):
    bl_idname = NODE_ID
    bl_label = NODE_LABEL

    screen: EnumProperty(
        name="Screen",
        items=[("green", "Green", ""), ("blue", "Blue", "")],
    )
    start_frame: IntProperty(name="Start Frame", default=1, update=set_start_frame)
    bake_end: IntProperty(name="End Frame", default=1)
    profile: EnumProperty(
        name="Model resolution",
        items=[
            ("720", "1280 × 720", "Use the 768 × 1280 FP16 profile"),
            ("1024", "1536 × 1024", "Use the optional 1024 × 1536 FP16 profile"),
        ],
    )
    status: StringProperty()

    def init(self, context):
        tree = bpy.data.node_groups.new("CorridorKey2.0", "CompositorNodeTree")
        tree.color_tag = "MATTE"
        add_image_input(tree)
        tree.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")
        tree.interface.new_socket(name="Matte", in_out="OUTPUT", socket_type="NodeSocketFloat")
        image_node = tree.nodes.new("CompositorNodeImage")
        image_node.name = "Keyed Frames"
        output = tree.nodes.new("NodeGroupOutput")
        output.location.x = 240
        add_processing_sockets(tree)
        organize_sockets(self, tree)
        update_image_output(tree)
        self.node_tree = tree
        self.width = 245

    def copy(self, source_node):
        self.node_tree = source_node.node_tree.copy()

    def update(self):
        # Inserting a node into an existing wire can bypass insert_link.
        if self.is_property_set("start_frame") and self.is_property_set("bake_end"):
            return
        scene = getattr(bpy.context, "scene", None)
        # Blender validates the new link after calling update.
        link = image_input_link(self, require_valid=False)
        if scene and link is not None:
            set_source_range(self, scene, link.from_node)

    def draw_buttons(self, context, layout):
        job = JOBS.get(self.as_pointer())
        fields = layout.column()
        fields.enabled = job is None
        linked = image_is_linked(self)
        for property_name, label in (("screen", "Screen"), ("profile", "Model resolution")):
            field = fields.split(factor=0.52, align=True)
            field.label(text=label)
            field.prop(self, property_name, text="")
        fields.prop(self, "start_frame")
        fields.prop(self, "bake_end")
        if job:
            layout.operator("node.corridorkey_mlx_cancel", text="Cancel").node_name = self.name
            if job.progress is None:
                layout.label(text=job.message)
            else:
                layout.progress(factor=job.progress, type="BAR", text=job.message)
        else:
            busy = bool(JOBS) and linked
            row = layout.row()
            row.enabled = linked and not busy
            row.operator(
                "node.corridorkey_mlx_analyze",
                text=ANALYSIS_BUSY_MESSAGE if busy else "Analyze",
            ).node_name = self.name
            if self.status and not busy:
                layout.label(text=self.status)


def add_image_input(tree):
    if not any(item.item_type == "SOCKET" and item.in_out == "INPUT" and item.name == "Image"
               for item in tree.interface.items_tree):
        socket = tree.interface.new_socket(name="Image", in_out="INPUT", socket_type="NodeSocketColor")
        socket.hide_value = True


def add_processing_sockets(tree):
    if any(item.item_type == "SOCKET" and item.in_out == "INPUT" and item.name == "Garbage Mask"
           for item in tree.interface.items_tree):
        return False
    for name, description in (
        ("Matte Hint", "Optional rough alpha for the first analyzed frame. White marks foreground. Reanalyze after changing it."),
        ("Garbage Mask", GARBAGE_MASK_DESCRIPTION),
    ):
        socket = tree.interface.new_socket(
            name=name, in_out="INPUT", socket_type="NodeSocketFloat", description=description,
        )
        socket.hide_value = True
        socket.default_value = 1 if name == "Garbage Mask" else 0
    for name, socket_type in (
        ("Despilled Foreground", "NodeSocketColor"),
        ("Raw Foreground", "NodeSocketColor"),
        ("Edges", "NodeSocketFloat"),
    ):
        tree.interface.new_socket(name=name, in_out="OUTPUT", socket_type=socket_type)

    nodes, links = tree.nodes, tree.links
    keyed = nodes["Keyed Frames"]
    output = next(node for node in nodes if node.type == "GROUP_OUTPUT" and node.is_active_output)
    group_input = next((node for node in nodes if node.type == "GROUP_INPUT"), None)
    if group_input is None:
        group_input = nodes.new("NodeGroupInput")
        group_input.location.x = -240

    keep = nodes.new("ShaderNodeMath")
    keep.operation = "MULTIPLY"
    keep.use_clamp = True
    keep.inputs[0].default_value = 1
    links.new(group_input.outputs["Garbage Mask"], keep.inputs[1])

    masked_image = nodes.new("CompositorNodeSetAlpha")
    masked_image.name = "Masked Image"
    links.new(keyed.outputs["Image"], masked_image.inputs["Image"])
    links.new(keep.outputs[0], masked_image.inputs["Alpha"])

    matte = nodes.new("ShaderNodeMath")
    matte.operation = "MULTIPLY"
    links.new(keyed.outputs["Alpha"], matte.inputs[0])
    links.new(keep.outputs[0], matte.inputs[1])
    links.new(matte.outputs[0], output.inputs["Matte"])

    edges = nodes.new("ShaderNodeMath")
    edges.operation = "SUBTRACT"
    for index, size in enumerate((1, -1)):
        boundary = nodes.new("CompositorNodeDilateErode")
        boundary.inputs["Size"].default_value = size
        links.new(matte.outputs[0], boundary.inputs["Mask"])
        links.new(boundary.outputs["Mask"], edges.inputs[index])
    links.new(edges.outputs[0], output.inputs["Edges"])

    for name in ("Despilled Foreground", "Raw Foreground"):
        foreground = nodes.new("CompositorNodeImage")
        foreground.name = name
        links.new(foreground.outputs["Image"], output.inputs[name])
    return True


def organize_sockets(node, tree):
    interface = tree.interface
    sockets = {
        (item.in_out, item.name): item for item in interface.items_tree
        if item.item_type == "SOCKET"
    }
    panel = next((item for item in interface.items_tree if item.item_type == "PANEL" and item.name == "More"), None)
    if panel is None:
        panel = interface.new_panel("More", default_closed=True)
    for index, name in enumerate(MORE_OUTPUTS):
        output = sockets["OUTPUT", name]
        if output.parent != panel:
            interface.move_to_parent(output, panel, index)
    hint = sockets["INPUT", "Matte Hint"]
    if hint.parent != panel:
        interface.move_to_parent(hint, panel, len(MORE_OUTPUTS))

    garbage = sockets["INPUT", "Garbage Mask"]
    if garbage.description != GARBAGE_MASK_DESCRIPTION:
        garbage.description = GARBAGE_MASK_DESCRIPTION
        garbage.default_value = 1
    keep = tree.nodes["Masked Image"].inputs["Alpha"].links[0].from_node
    if keep.operation == "SUBTRACT":
        keep.operation = "MULTIPLY"
    # Old node instances retain their socket defaults when the interface changes.
    mask_socket = node.inputs.get("Garbage Mask")
    if mask_socket is not None and mask_socket.default_value == 0:
        mask_socket.default_value = 1


def update_image_output(tree):
    keyed = tree.nodes["Keyed Frames"]
    output = next(node for node in tree.nodes if node.type == "GROUP_OUTPUT" and node.is_active_output)
    image_input = output.inputs["Image"]
    if keyed.image:
        source = tree.nodes["Masked Image"].outputs["Image"]
    else:
        group_input = next((node for node in tree.nodes if node.type == "GROUP_INPUT"), None)
        if group_input is None:
            group_input = tree.nodes.new("NodeGroupInput")
            group_input.location.x = -240
        source = group_input.outputs["Image"]
    if not any(link.from_socket == source for link in image_input.links):
        tree.links.new(source, image_input)

    hint = tree.nodes.get(UNBAKED_HINT_NODE)
    if keyed.image:
        if hint is not None:
            tree.nodes.remove(hint)
    elif hint is None:
        # Blender dims inputs with no path to an output. Keep the external
        # analysis input visible as active by passing a neutral mask factor.
        hint = tree.nodes.new("ShaderNodeMath")
        hint.name = UNBAKED_HINT_NODE
        hint.operation = "MULTIPLY_ADD"
        hint.inputs[1].default_value = 0
        hint.inputs[2].default_value = 1
        keep = tree.nodes["Masked Image"].inputs["Alpha"].links[0].from_node
        tree.links.new(group_input.outputs["Matte Hint"], hint.inputs[0])
        tree.links.new(hint.outputs[0], keep.inputs[0])


@persistent
def upgrade_image_inputs(_):
    for tree in getattr(bpy.data, "node_groups", ()):
        if tree.bl_idname == "CompositorNodeTree":
            for node in tree.nodes:
                if node.bl_idname == NODE_ID and node.node_tree and node.node_tree.is_editable:
                    if node.node_tree.color_tag in {"NONE", "GROUP"}:
                        node.node_tree.color_tag = "MATTE"
                    add_image_input(node.node_tree)
                    if add_processing_sockets(node.node_tree) and node.width == 260:
                        node.width = 245
                    organize_sockets(node, node.node_tree)
                    update_image_output(node.node_tree)
                    if node.status == "Connect Image or choose footage.":
                        node.status = ""
                    elif match := re.fullmatch(r"Ready · (\d+) frames", node.status):
                        node.status = f"{match[1]} frames analysed"


def upgrade_open_project():
    upgrade_image_inputs(None)


def image_input_link(node, require_valid=True, socket_name="Image"):
    socket = node.inputs.get(socket_name)
    if socket is not None:
        return next(
            (link for link in socket.links if not link.is_muted and (link.is_valid or not require_valid)),
            None,
        )
    return None


def image_is_linked(node):
    return image_input_link(node) is not None


def strip_compositor(scene, tree):
    editor = scene.sequence_editor
    strip = editor.active_strip if editor else None
    if strip:
        for modifier in strip.modifiers:
            if modifier.type == "COMPOSITOR" and modifier.node_group == tree:
                return strip, modifier
    return None, None


def set_source_range(node, scene, source):
    strip, _ = strip_compositor(scene, node.id_data)
    if strip:
        first, last = int(strip.frame_final_start), int(strip.frame_final_end) - 1
    else:
        visited = set()
        while source.type == "REROUTE" and source not in visited:
            visited.add(source)
            link = next((link for link in source.inputs[0].links if link.is_valid and not link.is_muted), None)
            if link is None:
                break
            source = link.from_node
        if source.bl_idname == "CompositorNodeImage" and source.image:
            first = source.frame_start
            if source.image.source == "MOVIE":
                duration = source.image.frame_duration
            elif source.image.source == "SEQUENCE":
                duration = source.frame_duration
            else:
                duration = 1
            last = first + max(duration, 1) - 1
        else:
            first, last = scene.frame_start, scene.frame_end
    # Keep any explicit range already entered on the node.
    if not node.is_property_set("start_frame"):
        node.start_frame = first
    if not node.is_property_set("bake_end"):
        node.bake_end = max(node.start_frame, last)


def bake_config(context, node, destination):
    scene = context.scene
    editor = context.space_data
    tree = node.id_data
    if editor.node_tree != tree:
        raise ValueError("Place CorridorKey at the top level of the scene compositor or strip modifier.")
    link = image_input_link(node)
    if link is None:
        raise ValueError("Connect the Image input before analyzing.")
    set_source_range(node, scene, link.from_node)
    last = node.bake_end
    if last < node.start_frame:
        raise ValueError("End Frame must be at or after Start Frame.")
    _, width, height = PROFILE_SIZES[node.profile]
    config = {
        "scene": scene.name, "node": node.name, "first": node.start_frame,
        "last": last, "width": width, "height": height,
        "destination": str(destination / "baked-input"),
        "source_node": link.from_node.name,
        "source_socket": link.from_socket.identifier,
    }
    if hint := image_input_link(node, socket_name="Matte Hint"):
        config["hint"] = {
            "node": hint.from_node.name,
            "socket": hint.from_socket.identifier,
            "path": str(destination / "matte-hint.png"),
        }
    strip, modifier = strip_compositor(scene, tree)
    if strip:
        if strip not in scene.sequence_editor.strips[:]:
            raise ValueError("Linked baking is available on top-level strips.")
        if not strip.frame_final_start <= node.start_frame <= last < strip.frame_final_end:
            raise ValueError("Set Start and End Frame inside the selected strip.")
        return dict(config, context="strip", strip=strip.name, effect=modifier.name)
    for index, effect in enumerate(scene.compositor_effects):
        if effect.node_group == tree:
            return dict(config, context="effect", effect=index)
    if scene.compositing_node_group == tree:
        return dict(config, context="scene")
    raise ValueError("Open the scene compositor or select the strip that uses this compositor modifier.")


def get_node(context, name):
    tree = getattr(context.space_data, "edit_tree", None)
    node = tree.nodes.get(name) if tree else None
    return node if node and node.bl_idname == NODE_ID else None


class CorridorKeyAnalyze(Operator):
    bl_idname = "node.corridorkey_mlx_analyze"
    bl_label = "Analyze with CorridorKey"
    bl_description = "Analyze the connected image and bake the keyed frames"

    node_name: StringProperty()

    def execute(self, context):
        if JOBS:
            self.report({"WARNING"}, ANALYSIS_BUSY_MESSAGE)
            return {"CANCELLED"}
        node = get_node(context, self.node_name)
        if not node:
            self.report({"ERROR"}, "Select a CorridorKey node.")
            return {"CANCELLED"}
        if not image_is_linked(node):
            return {"CANCELLED"}

        prefs = context.preferences.addons[ADDON_ID].preferences
        self.process = None
        self.snapshot = None
        try:
            executable, model_root, root = self.validate_paths(prefs, node)
            destination = root / uuid.uuid4().hex
            config = bake_config(context, node, destination)
            if config["context"] == "strip":
                python = executable.with_name("python")
                if not os.access(python, os.X_OK):
                    raise ValueError("The MLX executable must be in the backend environment's bin folder alongside Python.")
                config["python"] = str(python)
            destination.mkdir(parents=True)
            self.destination = destination
            self.log = destination / "analysis.log"
            self.baking = True
            self.progress = None
            self.message = "1/3 · Saving bake project…"
            self.snapshot = destination / "bake.blend"
            config_path = destination / "bake.json"
            config_path.write_text(json.dumps(config))
            job = bpy.ops.wm.save_as_mainfile(
                filepath=str(self.snapshot), copy=True, relative_remap=True,
                check_existing=False, show_save_modified_images_dialog=False,
            )
            if "FINISHED" not in job:
                raise RuntimeError("Could not save a copy of the project for baking.")
            source = Path(config["destination"])
            self.output = destination / "result"
            self.analysis_command = job_command(
                executable, model_root, source, self.output, node.screen, node.profile,
            )
            if hint := config.get("hint"):
                self.analysis_command.extend(("--hint-first-frame", hint["path"]))
            if config["context"] == "strip":
                self.analysis_command = [
                    config["python"], "-I", str(Path(__file__).with_name("fit_bake.py")), "key",
                    str(source / "geometry.json"), str(self.output), *self.analysis_command,
                ]
            self.launch([
                bpy.app.binary_path, "--background", "--factory-startup", "--disable-autoexec",
                "--python-exit-code", "1", str(self.snapshot),
                "--python", str(Path(__file__).with_name("bake_input.py")), "--", str(config_path),
            ])
        except (OSError, RuntimeError, ValueError) as error:
            self.remove_snapshot()
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        self.node = node
        self.node_pointer = node.as_pointer()
        self.start_frame = config["first"]
        self.area = context.area
        self.window_manager = context.window_manager
        self.cancelled = False
        JOBS[self.node_pointer] = self
        node.status = "Waiting for analysis result."
        self.timer = self.window_manager.event_timer_add(0.25, window=context.window)
        self.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def launch(self, command):
        with self.log.open("ab") as log:
            self.process = subprocess.Popen(
                command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                cwd=self.destination,
            )

    def remove_snapshot(self):
        if self.snapshot:
            try:
                self.snapshot.unlink(missing_ok=True)
            except OSError:
                pass

    @staticmethod
    def validate_paths(prefs, node):
        manual = bool(prefs.executable or prefs.model_root)
        if manual:
            if not prefs.executable or not prefs.model_root:
                raise ValueError("Set both paths in Advanced preferences or clear both to use automatic setup.")
            executable, model_root = absolute_path(prefs.executable), absolute_path(prefs.model_root)
        else:
            paths = setup_ui.managed_paths()
            if paths is None:
                raise ValueError("Click Set Up CorridorKey in the extension preferences first.")
            executable, model_root = paths
        if not executable.is_file() or not os.access(executable, os.X_OK):
            raise ValueError("Choose the executable corridorkey-mlx in the backend environment.")
        height, width, _ = PROFILE_SIZES[node.profile]
        profile_folder = f"{height}x{width}-t1"
        if node.profile == "1024" and not setup_ui.large_model_ready(model_root):
            raise ValueError("Download the 1536 × 1024 model in the extension preferences first.")
        if not (model_root / "fp16" / profile_folder / "stats.json").is_file():
            raise ValueError(f"FP16 profile {profile_folder} is missing from the model folder.")
        if prefs.cache_root:
            root = absolute_path(prefs.cache_root)
        elif bpy.data.filepath:
            root = Path(bpy.data.filepath).parent / "corridorkey-cache"
        else:
            root = setup_ui.runtime_root().parent / "analysis-cache"
        return executable, model_root, root

    def request_cancel(self):
        self.cancelled = True
        try:
            os.killpg(self.process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    def modal(self, context, event):
        if event.type != "TIMER":
            return {"PASS_THROUGH"}
        if self.process.poll() is None:
            self.read_progress()
            return {"PASS_THROUGH"}
        if self.baking and self.process.returncode == 0 and not self.cancelled:
            self.remove_snapshot()
            self.baking = False
            self.progress = None
            self.message = "2/3 · Loading model…"
            try:
                self.launch(self.analysis_command)
            except OSError as error:
                self.report({"ERROR"}, str(error))
                return self.finish(launch_failed=True)
            try:
                self.area.tag_redraw()
            except ReferenceError:
                pass
            return {"RUNNING_MODAL"}
        return self.finish()

    def read_progress(self):
        try:
            with self.log.open("rb") as log:
                log.seek(max(0, log.seek(0, os.SEEK_END) - 16384))
                matches = PROGRESS_LINE.findall(log.read())
            if matches:
                phase, current, total = matches[-1]
                if phase == b"Bake" and not self.baking:
                    return
                step, label = ANALYSIS_STAGES[phase]
                current, total = int(current), int(total)
                self.progress = min(current / max(total, 1), 1.0)
                self.message = f"{step}/3 · {label} {current}/{total}"
            self.area.tag_redraw()
        except (OSError, ReferenceError):
            pass

    def finish(self, launch_failed=False):
        self.window_manager.event_timer_remove(self.timer)
        JOBS.pop(self.node_pointer, None)
        self.remove_snapshot()
        try:
            if self.cancelled:
                self.node.status = "Analysis cancelled."
                return {"CANCELLED"}
            if launch_failed or self.process.returncode:
                self.node.status = "Bake failed. See analysis.log." if self.baking else "Analysis failed. See analysis.log."
                self.report({"ERROR"}, f"CorridorKey failed. See {self.log}")
                return {"CANCELLED"}

            frame_count = publish_sequence(self.node, self.output, self.start_frame)
            self.node.status = f"{frame_count} frames analysed"
            return {"FINISHED"}
        except (OSError, RuntimeError, ValueError) as error:
            self.node.status = "Could not load the result."
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        except ReferenceError:
            return {"CANCELLED"}
        finally:
            try:
                self.area.tag_redraw()
            except ReferenceError:
                pass

    def cancel(self, context):
        self.request_cancel()
        self.remove_snapshot()
        self.window_manager.event_timer_remove(self.timer)
        JOBS.pop(self.node_pointer, None)
        try:
            self.node.status = "Analysis cancelled."
        except ReferenceError:
            pass


class CorridorKeyCancel(Operator):
    bl_idname = "node.corridorkey_mlx_cancel"
    bl_label = "Cancel CorridorKey analysis"

    node_name: StringProperty()

    def execute(self, context):
        node = get_node(context, self.node_name)
        if node and (job := JOBS.get(node.as_pointer())):
            job.request_cancel()
            return {"FINISHED"}
        return {"CANCELLED"}


def draw_keying_menu(self, context):
    operator = self.layout.operator("node.add_node", text=NODE_LABEL)
    operator.type = NODE_ID
    operator.use_transform = True


CLASSES = (*setup_ui.CLASSES, CorridorKeyPreferences, CorridorKeyNode, CorridorKeyAnalyze, CorridorKeyCancel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.NODE_MT_category_compositor_keying.append(draw_keying_menu)
    bpy.app.handlers.load_post.append(upgrade_image_inputs)
    if not bpy.app.timers.is_registered(upgrade_open_project):
        bpy.app.timers.register(upgrade_open_project)


def unregister():
    if setup_ui.active_setup is not None:
        setup_ui.active_setup.cancel(None)
    for job in tuple(JOBS.values()):
        job.cancel(None)
    bpy.types.NODE_MT_category_compositor_keying.remove(draw_keying_menu)
    bpy.app.handlers.load_post.remove(upgrade_image_inputs)
    if bpy.app.timers.is_registered(upgrade_open_project):
        bpy.app.timers.unregister(upgrade_open_project)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
